<?php
$connect = mysqli_connect("localhost", "syrine", "", "online-voting-system");

?>